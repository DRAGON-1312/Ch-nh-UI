24127442@student.hcmus.edu.vn
dragon13122006

uvicorn app.main:app --reload --port 8000 --log-level info
cd frontend
.\.venv\Scripts\Activate   
python -m streamlit run app.py  

*schemas/ – Data definitions & validation (“shared language” for data – all layers reuse the same definitions)
- Meaning:
1. Contains Pydantic models that describe the shape of data for the module:
+ API request/response models
+ “Domain objects” used inside services
2. Does not call HTTP, does not query providers, and does not contain complex algorithms → it is only data structures + validation.

*services/ – Business logic / core algorithms
- Meaning:
1. Contains the core logic of the module:
+ Calls external providers (TrackAsia, SerpAPI, …)
+ Performs computations, applies algorithms and heuristics
+ Returns domain objects (NormalizedOrigin, NearbyResult, …)
2. Does not depend on HTTP / FastAPI:
+ No APIRouter, no Request / Response
+ Only takes and returns plain Python objects + Pydantic models.

*api/ – HTTP layer / FastAPI routers (“the door” for the outside world to call in)
- Meaning:
1. Contains FastAPI endpoints exposed to the frontend / clients:
+ Defines routes, methods, and query/body parameters
+ Calls the corresponding functions in services
+ Maps results to schemas response models.

*The file backend_client.py serves as a “bridge” between the Streamlit frontend and the FastAPI backend.



schemas/ - Định nghĩa dữ liệu & validation ("ngôn ngữ chung" cho dữ liệu - mọi layer dùng chung 1 định nghĩa)
Ý nghĩa: 1. chứa các model Pydantic mô tả hình dạng dữ liệu của module:
+ request/response của API
+ các "domain object" dùng trong services
2. Không gọi HTTP, không truy vấn provider, không chứa thuật toán phức tạp → chỉ là cấu trúc dữ liệu + validation.

services/ - Business logic/thuật toán lõi
Ý nghĩa: 1. Chứa core logic của module: 
+ gọi provider (TrackAsia, SerpAPI…)
+ xử lý tính toán, apply thuật toán, heuristic
+ trả về đối tượng domain (NormalizedOrigin, NearbyResult, …)
2. Không phụ thuộc HTTP / FastAPI:
+ không APIRouter, không Request/Response
+ chỉ nhận / trả về Python object + Pydantic models.

api/ - Lớp HTTP / FastAPI router (“cái cửa” để thế giới bên ngoài gọi vào)
Ý nghĩa: 
- Chứa các endpoint FastAPI expose ra cho FE / client:
+ định nghĩa route, method, query/body params
+ gọi sang hàm trong services
+ map kết quả sang schemas response.

File backend_client.py này đóng vai trò là “cầu nối” giữa frontend Streamlit và backend FastAPI